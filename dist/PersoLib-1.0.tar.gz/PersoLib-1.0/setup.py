from setuptools import setup

setup(
    name="PersoLib",
    version="1.0",
    packages=["perso_lib"]
)